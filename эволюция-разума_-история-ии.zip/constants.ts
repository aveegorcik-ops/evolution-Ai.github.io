import { TimelineEvent, ChartDataPoint } from './types';

export const TIMELINE_EVENTS: TimelineEvent[] = [
  {
    year: 1950,
    title: "Тест Тьюринга",
    description: "Алан Тьюринг публикует статью 'Computing Machinery and Intelligence', предлагая знаменитый тест для определения способности машины мыслить.",
    category: 'foundations'
  },
  {
    year: 1956,
    title: "Дартмутский семинар",
    description: "Рождение термина 'Искусственный Интеллект'. Джон Маккарти, Марвин Минский и другие определяют ключевые цели области.",
    category: 'foundations'
  },
  {
    year: 1966,
    title: "ELIZA",
    description: "Джозеф Вейценбаум создает ELIZA, первого чат-бота, пародирующего психотерапевта.",
    category: 'growth'
  },
  {
    year: 1974,
    title: "Первая 'Зима ИИ'",
    description: "Сокращение финансирования из-за завышенных ожиданий и недостаточной вычислительной мощности.",
    category: 'winter'
  },
  {
    year: 1997,
    title: "Deep Blue побеждает Каспарова",
    description: "Компьютер IBM впервые обыгрывает чемпиона мира по шахматам в матче.",
    category: 'boom'
  },
  {
    year: 2012,
    title: "AlexNet и глубокое обучение",
    description: "Сверточная нейросеть AlexNet выигрывает ImageNet, запуская революцию глубокого обучения.",
    category: 'boom'
  },
  {
    year: 2017,
    title: "Архитектура Transformer",
    description: "Google публикует 'Attention Is All You Need', закладывая основу для современных LLM.",
    category: 'modern'
  },
  {
    year: 2022,
    title: "ChatGPT и генеративный бум",
    description: "OpenAI выпускает ChatGPT, делая ИИ доступным для массового пользователя.",
    category: 'modern'
  },
  {
    year: 2024,
    title: "Эра Мультимодальности",
    description: "Gemini и другие модели демонстрируют способность понимать текст, видео, аудио и код одновременно.",
    category: 'modern'
  }
];

export const PARAMETER_GROWTH: ChartDataPoint[] = [
  { name: 'ELIZA', value: 0.0001, year: 1966 },
  { name: 'NetTalk', value: 0.02, year: 1986 },
  { name: 'LeNet-5', value: 0.06, year: 1998 },
  { name: 'AlexNet', value: 60, year: 2012 },
  { name: 'ResNet', value: 25000, year: 2015 },
  { name: 'GPT-2', value: 1500000, year: 2019 },
  { name: 'GPT-3', value: 175000000, year: 2020 },
  { name: 'Modern LLMs', value: 1000000000, year: 2024 },
];
